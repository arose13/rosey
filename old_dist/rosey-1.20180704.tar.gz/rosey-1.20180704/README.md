Rosey
===============================

author: Stephen Anthony Rose

Overview
--------

Data Science Utilities for statistics and machine learning.

Installation / Usage
--------------------

To install use pip:

    $ pip install rosey


Or clone the repo:

    $ git clone https://github.com/arose13/rosey.git
    $ python setup.py install
    
Contributing
------------

Me (Stephen Anthony Rose)

Example
-------

TBD